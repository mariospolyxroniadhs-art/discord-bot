import { pgTable, text, serial, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  sentBy: text("sent_by").notNull(),
  channelId: text("channel_id").notNull(),
  createdAt: text("created_at").notNull(), // using text for simplicity or timestamp
});

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true });

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
