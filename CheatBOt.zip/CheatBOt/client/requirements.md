## Packages
framer-motion | Complex animations for the gaming aesthetic
react-icons | Additional icons for social proof and features

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
