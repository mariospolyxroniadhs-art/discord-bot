import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: 'online' | 'offline' | 'maintenance';
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = {
    online: {
      color: "bg-green-500",
      label: "Operational",
      glow: "shadow-[0_0_15px_rgba(34,197,94,0.5)]"
    },
    offline: {
      color: "bg-red-500",
      label: "Offline",
      glow: "shadow-[0_0_15px_rgba(239,68,68,0.5)]"
    },
    maintenance: {
      color: "bg-yellow-500",
      label: "Maintenance",
      glow: "shadow-[0_0_15px_rgba(234,179,8,0.5)]"
    }
  };

  const current = config[status];

  return (
    <div className={cn(
      "inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/5 bg-black/20 backdrop-blur-sm",
      current.glow,
      className
    )}>
      <span className="relative flex h-3 w-3">
        <span className={cn(
          "animate-ping absolute inline-flex h-full w-full rounded-full opacity-75",
          current.color
        )}></span>
        <span className={cn(
          "relative inline-flex rounded-full h-3 w-3",
          current.color
        )}></span>
      </span>
      <span className="font-display font-medium text-sm tracking-wide uppercase text-white/90">
        {current.label}
      </span>
    </div>
  );
}
