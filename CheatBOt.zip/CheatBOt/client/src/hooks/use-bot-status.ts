import { useQuery } from "@tanstack/react-query";

// Mock API response since backend route isn't explicitly defined yet
// In a real app, this would fetch from /api/status
export interface BotStatus {
  status: 'online' | 'offline' | 'maintenance';
  uptime: string;
  servers: number;
  users: number;
  lastPing: string;
}

export function useBotStatus() {
  return useQuery({
    queryKey: ['bot-status'],
    queryFn: async (): Promise<BotStatus> => {
      // Simulating network delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      return {
        status: 'online',
        uptime: '24d 13h 45m',
        servers: 142,
        users: 15420,
        lastPing: '24ms'
      };
    },
    // Refresh every 30 seconds
    refetchInterval: 30000,
  });
}
