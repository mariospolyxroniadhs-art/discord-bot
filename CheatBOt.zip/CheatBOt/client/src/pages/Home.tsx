import { useBotStatus } from "@/hooks/use-bot-status";
import { StatusBadge } from "@/components/StatusBadge";
import { FeatureCard } from "@/components/FeatureCard";
import { 
  Bot, 
  ShieldCheck, 
  Zap, 
  MessageSquare, 
  Terminal, 
  Activity,
  Server,
  Users,
  ChevronRight
} from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: status, isLoading } = useBotStatus();

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/20 blur-[120px] rounded-full -z-10" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-emerald-500/10 blur-[100px] rounded-full -z-10" />

      {/* Navbar */}
      <nav className="container mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/20">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight">BotPanel</span>
        </div>
        <div className="flex items-center gap-4">
          <StatusBadge status={status?.status || 'offline'} />
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-grow container mx-auto px-6 py-12 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-5xl lg:text-7xl font-bold leading-[1.1] mb-6 glow-text">
                Next Level <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-indigo-400">
                  Discord Control
                </span>
              </h1>
              <p className="text-lg lg:text-xl text-muted-foreground max-w-xl leading-relaxed">
                Empower your community with advanced moderation, custom commands, and 24/7 uptime reliability.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button size="lg" className="text-lg h-14 px-8 rounded-xl bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all">
                Add to Discord
                <ChevronRight className="ml-2 w-5 h-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg h-14 px-8 rounded-xl border-white/10 bg-white/5 hover:bg-white/10 backdrop-blur-sm">
                View Documentation
              </Button>
            </motion.div>

            {/* Stats Grid */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="grid grid-cols-3 gap-4 pt-8 border-t border-white/5"
            >
              <div>
                <div className="text-2xl font-bold font-mono text-white mb-1">
                  {isLoading ? "..." : status?.servers}
                </div>
                <div className="text-sm text-muted-foreground flex items-center gap-1">
                  <Server className="w-3 h-3" /> Servers
                </div>
              </div>
              <div>
                <div className="text-2xl font-bold font-mono text-white mb-1">
                  {isLoading ? "..." : status?.users.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground flex items-center gap-1">
                  <Users className="w-3 h-3" /> Users
                </div>
              </div>
              <div>
                <div className="text-2xl font-bold font-mono text-emerald-400 mb-1">
                  {isLoading ? "..." : status?.lastPing}
                </div>
                <div className="text-sm text-muted-foreground flex items-center gap-1">
                  <Activity className="w-3 h-3" /> Ping
                </div>
              </div>
            </motion.div>
          </div>

          {/* Hero Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative lg:h-[600px] flex items-center justify-center"
          >
            <div className="relative w-full aspect-square max-w-[500px]">
              {/* Spinning rings */}
              <div className="absolute inset-0 rounded-full border border-primary/20 animate-[spin_10s_linear_infinite]" />
              <div className="absolute inset-8 rounded-full border border-white/5 animate-[spin_15s_linear_infinite_reverse]" />
              
              {/* Central Card */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="glass-card p-8 rounded-3xl w-64 h-64 flex flex-col items-center justify-center gap-4 border-primary/30 shadow-[0_0_50px_rgba(88,101,242,0.15)]">
                  <div className="w-24 h-24 bg-gradient-to-br from-primary to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <Bot className="w-12 h-12 text-white" />
                  </div>
                  <div className="text-center">
                    <div className="font-bold text-xl text-white">System Online</div>
                    <div className="text-sm text-emerald-400 font-mono mt-1 animate-pulse">
                      All systems operational
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div 
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-10 right-10 glass-card p-4 rounded-xl flex items-center gap-3"
              >
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="font-mono text-sm">Uptime: 99.9%</span>
              </motion.div>

              <motion.div 
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute bottom-20 left-0 glass-card p-4 rounded-xl flex items-center gap-3"
              >
                <Terminal className="w-4 h-4 text-primary" />
                <span className="font-mono text-sm">/command received</span>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Features Grid */}
        <div className="mt-32">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage and grow your Discord community with ease.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <FeatureCard 
              icon={ShieldCheck}
              title="Advanced Security"
              description="Protect your server with automated raid protection, anti-spam filters, and verification systems."
              delay={0}
            />
            <FeatureCard 
              icon={Terminal}
              title="Custom Commands"
              description="Create powerful custom commands without writing a single line of code. Complete freedom."
              delay={0.1}
            />
            <FeatureCard 
              icon={Zap}
              title="Instant Responses"
              description="Lightning fast execution times ensure your members never have to wait for the bot."
              delay={0.2}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 mt-24">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Bot className="w-5 h-5" />
            <span className="font-medium">BotPanel © 2024</span>
          </div>
          <div className="flex gap-8 text-sm text-muted-foreground">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Support Server</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
