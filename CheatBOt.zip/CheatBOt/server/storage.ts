import { db } from "./db";
import { messages, type InsertMessage } from "@shared/schema";

export interface IStorage {
  logMessage(message: InsertMessage): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async logMessage(message: InsertMessage): Promise<void> {
    await db.insert(messages).values(message);
  }
}

export const storage = new DatabaseStorage();
