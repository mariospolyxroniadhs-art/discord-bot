import { 
  Client, 
  GatewayIntentBits, 
  REST, 
  Routes, 
  SlashCommandBuilder,
  TextChannel,
  VoiceChannel,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
  ChannelType,
  ComponentType,
  AuditLogEvent
} from "discord.js";

// Check for required environment variables
if (!process.env.DISCORD_TOKEN) {
  console.warn("DISCORD_TOKEN is not set. Bot will not start.");
}

const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
  ] 
});

let giveawayParticipants: string[] = [];
let giveawayMessageId: string | null = null;
let giveawayControlMessageId: string | null = null;
let giveawayActive = false;
let giveawayResetTimeout: NodeJS.Timeout | null = null;

const commands = [
  new SlashCommandBuilder()
    .setName('send')
    .setDescription('Sends a message as the bot (Founder only)')
    .addStringOption(option =>
      option.setName('message')
        .setDescription('The message to send')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('setup-tickets')
    .setDescription('Setup the ticket system (Founder only)'),
  new SlashCommandBuilder()
    .setName('user-info')
    .setDescription('Get information about a user')
    .addUserOption(option => 
      option.setName('target')
        .setDescription('The user to get information about')
        .setRequired(false)
    ),
  new SlashCommandBuilder()
    .setName('set-up-giveaway')
    .setDescription('Setup a giveaway (Founder only)')
    .addStringOption(option =>
      option.setName('message')
        .setDescription('The text to display in the giveaway')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('dmall')
    .setDescription('Send a DM to everyone in the server (Founder only)')
    .addStringOption(option =>
      option.setName('message')
        .setDescription('The message to send')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('dm')
    .setDescription('Send a DM to a specific user (Founder only)')
    .addUserOption(option =>
      option.setName('target')
        .setDescription('The user to send the DM to')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('message')
        .setDescription('The message to send')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user (Founder only)')
    .addUserOption(option => option.setName('target').setDescription('The user to ban').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('The reason for banning')),
  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a user (Founder only)')
    .addUserOption(option => option.setName('target').setDescription('The user to kick').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('The reason for kicking')),
  new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute a user (Founder only)')
    .addUserOption(option => option.setName('target').setDescription('The user to mute').setRequired(true))
    .addIntegerOption(option => option.setName('duration').setDescription('Duration in minutes').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('The reason for muting')),
  new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmute a user (Founder only)')
    .addUserOption(option => option.setName('target').setDescription('The user to unmute').setRequired(true)),
  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Clear messages (Founder only)')
    .addIntegerOption(option => option.setName('amount').setDescription('Number of messages to clear (1-100)').setRequired(true)),
  new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set channel slowmode (Founder only)')
    .addIntegerOption(option => option.setName('seconds').setDescription('Slowmode in seconds').setRequired(true)),
  new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('Nuke the current channel (Founder only)'),
  new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock the current channel (Founder only)'),
  new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock the current channel (Founder only)'),
  new SlashCommandBuilder()
    .setName('server-info')
    .setDescription('Get information about the server (Founder only)'),
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot latency (Founder only)'),
].map(command => command.toJSON());

export async function setupDiscordBot() {
  if (!process.env.DISCORD_TOKEN) return;

  try {
    await client.login(process.env.DISCORD_TOKEN);
    console.log(`Logged in as ${client.user?.tag}!`);

    const SECURITY_LOG_CHANNEL_ID = "1466058869603303599";
    const WHITELISTED_BOT_IDS = ["1462536650730110998"]; // Our bot's ID

    // --- Server Stats Updater ---
    const STATS_MEMBERS_CHANNEL_ID = "1348441333341360249";
    const STATS_BOTS_CHANNEL_ID = "1348441763056189443";

    const updateServerStats = async (guild: any) => {
      try {
        // Fetch all members to ensure cache is populated
        const allMembers = await guild.members.fetch();
        const membersCount = allMembers.filter((m: any) => !m.user.bot).size;
        const botsCount = allMembers.filter((m: any) => m.user.bot).size;

        const membersChannel = await guild.channels.fetch(STATS_MEMBERS_CHANNEL_ID).catch(() => null);
        const botsChannel = await guild.channels.fetch(STATS_BOTS_CHANNEL_ID).catch(() => null);

        if (membersChannel) {
          await membersChannel.setName(`👥Members: ${membersCount}`).catch(console.error);
        }
        if (botsChannel) {
          await botsChannel.setName(`🤖Bots: ${botsCount}`).catch(console.error);
        }
      } catch (error) {
        console.error("Error updating server stats:", error);
      }
    };

    client.on('guildMemberRemove', async (member) => {
      await updateServerStats(member.guild);
    });

    client.on('ready', async () => {
      console.log(`Logged in as ${client.user?.tag}!`);
      // Initial update for all guilds
      client.guilds.cache.forEach(guild => updateServerStats(guild));
    });

    // Update stats on join/leave
    client.on('guildMemberAdd', async (member) => {
      await updateServerStats(member.guild);
      
      // ... existing code ...
      // Security: Ban any joining bots that are not whitelisted
      if (member.user.bot && !WHITELISTED_BOT_IDS.includes(member.user.id)) {
        try {
          await member.ban({ reason: '🛡️ Anti-Bot Security: Unauthorized bot join attempt.' });
          const logChannel = await member.guild.channels.fetch(SECURITY_LOG_CHANNEL_ID).catch(() => null) as TextChannel | null;
          if (logChannel) {
            await logChannel.send({
              embeds: [{
                title: '🛡️ Security Alert: Bot Banned',
                description: `**Bot:** <@${member.id}> (${member.user.tag})\n**Action:** Auto-Ban\n**Reason:** Unauthorized bot join attempt.`,
                color: 0xFF0000,
                timestamp: new Date().toISOString()
              }]
            });
          }
        } catch (error) {
          console.error('Error banning unauthorized bot:', error);
        }
        return;
      }
      
      const AUTO_ROLE_ID = "1348429304953962536";
      try {
        await member.roles.add(AUTO_ROLE_ID);
      } catch (err) {
        console.error("Failed to add auto-role:", err);
      }
    });

    client.on('channelCreate', async (channel) => {
      if (!(channel instanceof TextChannel || channel instanceof VoiceChannel)) return;
      
      try {
        const auditLog = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelCreate }).catch(() => null);
        const entry = auditLog?.entries.first();
        if (!entry) return;

        const executor = entry.executor;
        if (!executor) return;

        // Strict Anti-Nuke: If a bot (not whitelisted) creates a channel, delete it and ban the bot
        if (executor.bot && !WHITELISTED_BOT_IDS.includes(executor.id)) {
          await channel.delete('🛡️ Anti-Nuke: Unauthorized channel creation by bot.');
          const member = await channel.guild.members.fetch(executor.id).catch(() => null);
          if (member) {
            await member.ban({ reason: '🛡️ Anti-Nuke: Unauthorized channel creation.' });
          }

          const logChannel = await channel.guild.channels.fetch(SECURITY_LOG_CHANNEL_ID).catch(() => null) as TextChannel | null;
          if (logChannel) {
            await logChannel.send({
              embeds: [{
                title: '🛡️ Security Alert: Anti-Nuke Triggered',
                description: `**Bot:** <@${executor.id}>\n**Action:** Channel Deleted & Bot Banned\n**Trigger:** Unauthorized channel creation.`,
                color: 0xFF0000,
                timestamp: new Date().toISOString()
              }]
            });
          }
        }
      } catch (error) {
        console.error('Error in Anti-Nuke channel monitor:', error);
      }
    });

    client.on('channelDelete', async (channel) => {
      // Security Alert for manual channel deletion
      try {
        const auditLog = await (channel as any).guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete }).catch(() => null);
        const entry = auditLog?.entries.first();
        if (!entry) return;

        const executor = entry.executor;
        if (!executor) return;

        if (executor.id === client.user?.id) return; // Ignore our own actions

        const logChannel = await (channel as any).guild.channels.fetch(SECURITY_LOG_CHANNEL_ID).catch(() => null) as TextChannel | null;
        if (logChannel) {
          await logChannel.send({
            embeds: [{
              title: '🛡️ Security Alert: Channel Deleted',
              description: `**User:** <@${executor.id}>\n**Channel:** \`#${(channel as any).name}\`\n**Action:** Monitor for suspicious activity.`,
              color: 0xFF0000,
              timestamp: new Date().toISOString()
            }]
          });
        }
      } catch (error) {
        console.error('Error in channel delete monitor:', error);
      }
    });

    client.on('guildAuditLogEntryCreate', async (auditLog, guild) => {
      const { action, executorId, targetId } = auditLog;

      // BOT_ADD action is 28
      if (action === AuditLogEvent.BotAdd) {
        // Whitelist our own bot
        const whitelist = ["1462536650730110998"]; 
        if (targetId && whitelist.includes(targetId)) return;

        try {
          const target = await client.users.fetch(targetId!);
          if (target.bot) {
            await guild.members.ban(targetId!, { reason: '🛡️ Anti-Bot Security: Unauthorized application integration.' });
            const logChannel = await guild.channels.fetch(SECURITY_LOG_CHANNEL_ID).catch(() => null) as TextChannel | null;
            if (logChannel) {
              await logChannel.send({
                embeds: [{
                  title: '🛡️ Security Alert: Application Banned',
                  description: `An external application/integration was detected and blocked.\n**Bot:** <@${targetId}>\n**Added by:** <@${executorId}>`,
                  color: 0xFF0000,
                  timestamp: new Date().toISOString()
                }]
              });
            }
          }
        } catch (error) {
          console.error('Error banning application:', error);
        }
      }
    });

    // Anti-Nuke: Monitor Channel Deletions (Comprehensive)
    client.on('channelDelete', async (channel) => {
      if (channel.type === ChannelType.DM) return;
      const guild = (channel as any).guild;
      if (!guild) return;

      try {
        const auditLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete });
        const entry = auditLogs.entries.first();
        if (entry) {
          const { executor } = entry;
          if (executor && executor.id !== client.user?.id) {
            // If it's a bot not whitelisted, ban it
            if (executor.bot && !WHITELISTED_BOT_IDS.includes(executor.id)) {
              const member = await guild.members.fetch(executor.id).catch(() => null);
              if (member) await member.ban({ reason: '🛡️ Anti-Nuke: Unauthorized channel deletion.' });
            }

            const logChannel = await guild.channels.fetch(SECURITY_LOG_CHANNEL_ID).catch(() => null) as TextChannel | null;
            if (logChannel) {
              await logChannel.send({
                embeds: [{
                  title: '🛡️ Security Alert: Channel Deleted',
                  description: `**Channel:** \`#${(channel as any).name}\`\n**Action by:** <@${executor.id}>\n**Status:** Monitor for mass deletion!`,
                  color: 0xFF0000,
                  timestamp: new Date().toISOString()
                }]
              });
            }
          }
        }
      } catch (error) {
        console.error('Error monitoring anti-nuke delete:', error);
      }
    });

    client.on('interactionCreate', async interaction => {
      const SUPPORT_ROLE_ID = "1348431461589454942";
      const OWNER_ROLE_ID = "1348428921334534154";
      const FOUNDER_ROLE_ID = "1348428921334534154";

      if (interaction.isChatInputCommand()) {
        const SECURITY_LOG_CHANNEL_ID = "1466058869603303599";
        const GIVEAWAY_LOG_CHANNEL_ID = "1463432345976700984";
        const GIVEAWAY_CONTROL_CHANNEL_ID = "1463432745425436827";
        const FOUNDER_USER_ID = "1265288695318315040";

        if (interaction.commandName === 'set-up-giveaway') {
          if (interaction.user.id !== "1265288695318315040") {
            return interaction.reply({ content: 'Only the specified Founder can use this command.', ephemeral: true });
          }

          const joinButton = new ButtonBuilder()
            .setCustomId('join_giveaway')
            .setLabel('Join Giveaway')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('🎉');

          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(joinButton);

          const giveawayText = interaction.options.getString('message');

          const giveawayEmbed = {
            title: '🎁 GIVEAWAY STARTED!',
            description: giveawayText || 'Click the button below to participate in the giveaway!',
            color: 0xFF0000,
            footer: { text: 'Cheat Shop | Giveaway' }
          };

          const giveawayChan = interaction.channel;
          if (!giveawayChan || !(giveawayChan instanceof TextChannel)) {
            return interaction.reply({ content: 'Giveaway must be started in a text channel.', ephemeral: true });
          }

          const giveawayMsg = await giveawayChan.send({
            embeds: [giveawayEmbed],
            components: [row]
          });

          giveawayMessageId = giveawayMsg.id;
          giveawayActive = true;
          giveawayParticipants = [];

          const controlChannel = interaction.guild?.channels.cache.get("1463432745425436827") as TextChannel;
          if (controlChannel) {
            const controlButtons = new ActionRowBuilder<ButtonBuilder>().addComponents(
              new ButtonBuilder().setCustomId('stop_giveaway').setLabel('Stop Giveaway').setStyle(ButtonStyle.Danger),
              new ButtonBuilder().setCustomId('start_draw').setLabel('Start Draw').setStyle(ButtonStyle.Success)
            );

            await controlChannel.send({
              embeds: [{
                title: '⚙️ Giveaway Control',
                description: 'Use the buttons below to manage the active giveaway.',
                color: 0xFF0000
              }],
              components: [controlButtons]
            });
          }

          await interaction.reply({ content: 'Giveaway setup complete!', ephemeral: true });
        }
        if (interaction.commandName === 'send') {
          const member = interaction.member;
          if (!member) return interaction.reply({ content: 'Error checking roles.', ephemeral: true });
          const roleIds = 'roles' in member ? (Array.isArray(member.roles) ? member.roles : member.roles.cache.map(r => r.id)) : [];
          if (!roleIds.includes(FOUNDER_ROLE_ID)) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
          }
          const messageContent = interaction.options.getString('message');
          const channel = interaction.channel;
          if (channel && channel instanceof TextChannel && messageContent) {
            await channel.send({ embeds: [{ description: messageContent, color: 0xFF0000 }] });
            await interaction.reply({ content: `Message sent successfully!`, ephemeral: true });
          }
        }

        if (interaction.commandName === 'setup-tickets') {
          const member = interaction.member;
          const roleIds = 'roles' in member! ? (Array.isArray(member.roles) ? member.roles : member.roles.cache.map(r => r.id)) : [];
          if (!roleIds.includes(FOUNDER_ROLE_ID) && interaction.user.id !== FOUNDER_USER_ID) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
          }
          const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('ticket_select')
            .setPlaceholder('Select a category')
            .addOptions([
              { label: 'Buy something', description: 'Purchase products or services', value: 'buy_something', emoji: '💸' },
              { label: 'Question', description: 'Ask a question', value: 'question', emoji: '❓' },
              { label: 'Support', description: 'Create a support ticket', value: 'support', emoji: '📞' },
              { label: 'Scam', description: 'Report a scam', value: 'scam', emoji: '⚠️' },
              { label: 'Owner', description: 'Talk with owner', value: 'owner', emoji: '👑' },
              { label: 'Trade', description: 'Trade items', value: 'trade', emoji: '🤝' },
              { label: 'Request for role', description: 'Role requests', value: 'request_role', emoji: '🙏' },
            ]);
          const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);
          if (interaction.channel && interaction.channel instanceof TextChannel) {
            await interaction.channel.send({
              embeds: [{
                title: 'Ticket System',
                description: 'To create a ticket, select one of the options below.\nSupport will be with you as soon as possible.',
                color: 0xFF0000,
                thumbnail: { url: client.user?.displayAvatarURL() || '' }
              }],
              components: [row]
            });
            await interaction.reply({ content: 'Ticket system setup complete!', ephemeral: true });
          }
        }

        if (interaction.commandName === 'user-info') {
          const targetUser = interaction.options.getUser('target') || interaction.user;
          const member = await interaction.guild?.members.fetch(targetUser.id);
          if (!member) return interaction.reply({ content: 'Could not find user.', ephemeral: true });
          const roles = member.roles.cache.filter(role => role.name !== '@everyone').map(role => `<@&${role.id}>`).join(', ') || 'No roles';
          await interaction.reply({
            embeds: [{
              title: `👤 ${targetUser.username}`,
              description: `**Πληροφορίες Χρήστη**\nID: \`${targetUser.id}\`\nΌνομα: <@${targetUser.id}>\nΕγγραφή στο Discord: <t:${Math.floor(targetUser.createdAt.getTime() / 1000)}:F> (<t:${Math.floor(targetUser.createdAt.getTime() / 1000)}:R>)\n\n**Πληροφορίες Μέλους**\nΕίσοδος στον Server: ${member.joinedAt ? `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:F> (<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>)` : 'Άγνωστο'}\n\n**Roles**\n${roles}`,
              thumbnail: { url: targetUser.displayAvatarURL({ size: 512 }) },
              color: 0xFF0000,
              footer: { text: 'Cheat Shop | User Info', icon_url: client.user?.displayAvatarURL() }
            }],
            ephemeral: true
          });
        }

        if (interaction.commandName === 'dmall') {
          const member = interaction.member;
          const roleIds = 'roles' in member! ? (Array.isArray(member.roles) ? member.roles : member.roles.cache.map(r => r.id)) : [];
          if (!roleIds.includes(FOUNDER_ROLE_ID) && interaction.user.id !== FOUNDER_USER_ID) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
          }

          const dmMessage = interaction.options.getString('message');
          if (!dmMessage) return interaction.reply({ content: 'Please provide a message.', ephemeral: true });

          await interaction.reply({ content: 'Starting to send DMs to all members... This may take a while.', ephemeral: true });

          const members = await interaction.guild?.members.fetch();
          if (!members) return;

          let successCount = 0;
          let failCount = 0;

          const memberArray = Array.from(members.values());
          for (const m of memberArray) {
            if (m.user.bot) continue;
            try {
              await m.send({
                embeds: [{
                  title: '📢 Announcement from Cheat Shop',
                  description: dmMessage,
                  color: 0xFF0000,
                  footer: { text: 'Cheat Shop | Server Announcement' }
                }]
              });
              successCount++;
            } catch (err) {
              failCount++;
            }
          }

          await interaction.followUp({ 
            content: `DM broadcast complete!\n✅ Successful: ${successCount}\n❌ Failed (DMs closed): ${failCount}`, 
            ephemeral: true 
          });
        }

        if (interaction.commandName === 'dm') {
          const member = interaction.member;
          const roleIds = 'roles' in member! ? (Array.isArray(member.roles) ? member.roles : member.roles.cache.map(r => r.id)) : [];
          if (!roleIds.includes(FOUNDER_ROLE_ID) && interaction.user.id !== FOUNDER_USER_ID) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
          }

          const targetUser = interaction.options.getUser('target');
          const dmMessage = interaction.options.getString('message');

          if (!targetUser || !dmMessage) {
            return interaction.reply({ content: 'Invalid parameters.', ephemeral: true });
          }

          try {
            await targetUser.send({
              embeds: [{
                title: '📢 Message from Cheat Shop',
                description: dmMessage,
                color: 0xFF0000,
                footer: { text: 'Cheat Shop | Private Message' }
              }]
            });
            await interaction.reply({ content: `✅ Successfully sent DM to <@${targetUser.id}>.`, ephemeral: true });
          } catch (err) {
            await interaction.reply({ content: `❌ Failed to send DM to <@${targetUser.id}>. They may have DMs closed.`, ephemeral: true });
          }
        }

        // --- NEW FOUNDER COMMANDS ---
        if (['ban', 'kick', 'mute', 'unmute', 'clear', 'slowmode', 'nuke', 'lock', 'unlock', 'server-info', 'ping'].includes(interaction.commandName)) {
          const member = interaction.member;
          const roleIds = 'roles' in member! ? (Array.isArray(member.roles) ? member.roles : member.roles.cache.map(r => r.id)) : [];
          
          if (!roleIds.includes(FOUNDER_ROLE_ID) && interaction.user.id !== FOUNDER_USER_ID) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
          }

          try {
            if (interaction.commandName === 'ban') {
              const target = interaction.options.getMember('target') as any;
              const reason = interaction.options.getString('reason') || 'No reason provided';
              if (!target) return interaction.reply({ content: 'User not found.', ephemeral: true });
              await target.ban({ reason });
              await interaction.reply({ embeds: [{ title: '🚫 User Banned', description: `**User:** <@${target.id}>\n**Reason:** ${reason}`, color: 0xFF0000 }] });
            } else if (interaction.commandName === 'kick') {
              const target = interaction.options.getMember('target') as any;
              const reason = interaction.options.getString('reason') || 'No reason provided';
              if (!target) return interaction.reply({ content: 'User not found.', ephemeral: true });
              await target.kick(reason);
              await interaction.reply({ embeds: [{ title: '👢 User Kicked', description: `**User:** <@${target.id}>\n**Reason:** ${reason}`, color: 0xFF0000 }] });
            } else if (interaction.commandName === 'mute') {
              const target = interaction.options.getMember('target') as any;
              const duration = interaction.options.getInteger('duration');
              const reason = interaction.options.getString('reason') || 'No reason provided';
              if (!target) return interaction.reply({ content: 'User not found.', ephemeral: true });
              await target.timeout(duration! * 60 * 1000, reason);
              await interaction.reply({ embeds: [{ title: '🔇 User Muted', description: `**User:** <@${target.id}>\n**Duration:** ${duration}m\n**Reason:** ${reason}`, color: 0xFF0000 }] });
            } else if (interaction.commandName === 'unmute') {
              const target = interaction.options.getMember('target') as any;
              if (!target) return interaction.reply({ content: 'User not found.', ephemeral: true });
              await target.timeout(null);
              await interaction.reply({ embeds: [{ title: '🔊 User Unmuted', description: `**User:** <@${target.id}>`, color: 0xFF0000 }] });
            } else if (interaction.commandName === 'clear') {
              const amount = interaction.options.getInteger('amount');
              if (!amount || amount < 1 || amount > 100) return interaction.reply({ content: 'Amount must be between 1 and 100.', ephemeral: true });
              const channel = interaction.channel as TextChannel;
              await channel.bulkDelete(amount);
              await interaction.reply({ content: `✅ Cleared ${amount} messages.`, ephemeral: true });
            } else if (interaction.commandName === 'slowmode') {
              const seconds = interaction.options.getInteger('seconds');
              const channel = interaction.channel as TextChannel;
              await channel.setRateLimitPerUser(seconds!);
              await interaction.reply({ embeds: [{ title: '⏳ Slowmode Updated', description: `Slowmode is now set to **${seconds}** seconds.`, color: 0xFF0000 }] });
            } else if (interaction.commandName === 'nuke') {
              const channel = interaction.channel as TextChannel;
              const position = channel.position;
              const newChannel = await channel.clone();
              await channel.delete();
              await newChannel.setPosition(position);
              await newChannel.send({ embeds: [{ title: '☢️ Channel Nuked', description: 'This channel has been cleared and recreated.', color: 0xFF0000 }] });
            } else if (interaction.commandName === 'lock') {
              const channel = interaction.channel as TextChannel;
              await channel.permissionOverwrites.edit(interaction.guild!.id, { SendMessages: false });
              await interaction.reply({ embeds: [{ title: '🔒 Channel Locked', description: 'Members can no longer send messages in this channel.', color: 0xFF0000 }] });
            } else if (interaction.commandName === 'unlock') {
              const channel = interaction.channel as TextChannel;
              await channel.permissionOverwrites.edit(interaction.guild!.id, { SendMessages: true });
              await interaction.reply({ embeds: [{ title: '🔓 Channel Unlocked', description: 'Members can now send messages in this channel.', color: 0xFF0000 }] });
            } else if (interaction.commandName === 'server-info') {
              const guild = interaction.guild!;
              await interaction.reply({
                embeds: [{
                  title: `📊 ${guild.name} Info`,
                  description: `**ID:** \`${guild.id}\`\n**Owner:** <@${guild.ownerId}>\n**Members:** ${guild.memberCount}\n**Created:** <t:${Math.floor(guild.createdAt.getTime() / 1000)}:R>`,
                  thumbnail: { url: guild.iconURL() || '' },
                  color: 0xFF0000
                }]
              });
            } else if (interaction.commandName === 'ping') {
              await interaction.reply({ embeds: [{ title: '🏓 Pong!', description: `Latency: \`${client.ws.ping}ms\``, color: 0xFF0000 }] });
            }
          } catch (error) {
            console.error(`Error executing ${interaction.commandName}:`, error);
            if (!interaction.replied && !interaction.deferred) {
              await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
            }
          }
        }
      }

      if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select') {
        const guild = interaction.guild!;
        const user = interaction.user;
        const type = interaction.values[0];
        const existingTicket = guild.channels.cache.find(ch => ch.name.toLowerCase() === `${user.username.toLowerCase()}-ticket`);
        if (existingTicket) return interaction.reply({ content: '❌ You already have an open ticket!', ephemeral: true });

        // Reset menu
        await interaction.update({ components: interaction.message.components });

        const ticketChannel = await guild.channels.create({
          name: `${user.username}-Ticket`,
          type: ChannelType.GuildText,
          permissionOverwrites: [
            { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: SUPPORT_ROLE_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: OWNER_ROLE_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
          ],
        });

        // Send notification to support-notifications channel
        const NOTIF_CHANNEL_ID = "1464401027699703980";
        try {
          const notifChannel = await guild.channels.fetch(NOTIF_CHANNEL_ID).catch(() => null) as TextChannel | null;
          if (notifChannel && notifChannel.isTextBased()) {
            const goToTicketButton = new ActionRowBuilder<ButtonBuilder>().addComponents(
              new ButtonBuilder()
                .setLabel('Go to Ticket')
                .setURL(`https://discord.com/channels/${guild.id}/${ticketChannel.id}`)
                .setStyle(ButtonStyle.Link)
            );

            await notifChannel.send({
              embeds: [{
                title: '📩 New Support Ticket',
                description: `👤 **User:** <@${user.id}> (${user.username})\n📂 **Category:** \`${type.replace('_', ' ')}\`\n📍 **Channel:** <#${ticketChannel.id}>\n\n**Status:** Waiting for staff...`,
                color: 0xFF0000,
                timestamp: new Date().toISOString()
              }],
              components: [goToTicketButton]
            }).catch(e => console.error('Failed to send support notification:', e));
          } else {
            console.warn(`Support notification channel ${NOTIF_CHANNEL_ID} not found or not text-based.`);
          }
        } catch (error) {
          console.error('Error fetching support notification channel:', error);
        }

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId('claim_ticket').setLabel('Claim').setStyle(ButtonStyle.Secondary).setEmoji('📜'),
          new ButtonBuilder().setCustomId('close_ticket').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒')
        );

        await ticketChannel.send({
          content: `<@${user.id}> 👋 Please describe the reason you opened this ticket.`,
          embeds: [{
            title: 'Ticket Opened',
            description: `<@${user.id}> created a new **${type.replace('_', ' ')}** ticket.`,
            color: 0xFF0000,
            footer: { text: 'Cheat Shop | Support' }
          }],
          components: [row]
        });

        await interaction.followUp({ 
          content: `✅ Your ticket has been created: <#${ticketChannel.id}>`, 
          components: [new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setLabel('Go to Ticket').setURL(`https://discord.com/channels/${guild.id}/${ticketChannel.id}`).setStyle(ButtonStyle.Link))],
          ephemeral: true 
        });
      }

      if (interaction.isButton()) {
        const channel = interaction.channel;
        if (!channel || !(channel instanceof TextChannel)) return;
        const GIVEAWAY_LOG_CHANNEL_ID = "1463432345976700984";
        const GIVEAWAY_CONTROL_CHANNEL_ID = "1463432745425436827";
        const FOUNDER_ROLE_ID = "1348428921334534154";

        if (interaction.customId === 'join_giveaway') {
          if (!giveawayActive) return interaction.reply({ content: 'The giveaway has ended.', ephemeral: true });
          if (giveawayParticipants.includes(interaction.user.id)) {
            return interaction.reply({ content: 'You have already joined the giveaway!', ephemeral: true });
          }

          giveawayParticipants.push(interaction.user.id);
          
          try {
            await interaction.user.send('✅ You have successfully joined the giveaway! Good luck!');
          } catch (e) {
            console.error('Could not send DM to user');
          }

          const logChannel = interaction.guild?.channels.cache.get(GIVEAWAY_LOG_CHANNEL_ID) as TextChannel;
          if (logChannel) {
            await logChannel.send({ content: `👤 <@${interaction.user.id}> has joined the giveaway!` });
          }

          await interaction.reply({ content: 'You joined the giveaway!', ephemeral: true });
        }

        if (interaction.customId === 'stop_giveaway') {
          const member = interaction.member as any;
          if (!member.roles.cache.has(FOUNDER_ROLE_ID)) {
            return interaction.reply({ content: 'Only the Founder can stop the giveaway.', ephemeral: true });
          }

          giveawayActive = false;
          
          // 1. Cleanup ALL messages in LOG channel
          const logChannel = interaction.guild?.channels.cache.get(GIVEAWAY_LOG_CHANNEL_ID) as TextChannel;
          if (logChannel) {
            try {
              const messages = await logChannel.messages.fetch({ limit: 100 });
              if (messages.size > 0) {
                await logChannel.bulkDelete(messages).catch(console.error);
              }
            } catch (err) { console.error('Error clearing log channel:', err); }
          }

          // 2. Cleanup ORIGINAL giveaway message
          if (giveawayMessageId) {
            try {
              const giveawayChan = interaction.guild?.channels.cache.find(c => c.isTextBased() && (c as TextChannel).messages.cache.has(giveawayMessageId!)) as TextChannel;
              if (giveawayChan) {
                const msg = await giveawayChan.messages.fetch(giveawayMessageId).catch(() => null);
                if (msg) await msg.delete().catch(() => null);
              }
            } catch (err) { console.error('Error deleting giveaway message:', err); }
          }

          // 3. Cleanup ALL messages in CONTROL channel
          const controlChannel = interaction.guild?.channels.cache.get(GIVEAWAY_CONTROL_CHANNEL_ID) as TextChannel;
          if (controlChannel) {
            try {
              const messages = await controlChannel.messages.fetch({ limit: 100 });
              if (messages.size > 0) {
                await controlChannel.bulkDelete(messages).catch(console.error);
              }
            } catch (err) { console.error('Error clearing control channel:', err); }
          }

          await interaction.reply({ content: 'Giveaway stopped and all messages cleared.', ephemeral: true });
        }

        if (interaction.customId === 'start_draw') {
          const member = interaction.member as any;
          if (!member.roles.cache.has(FOUNDER_ROLE_ID)) {
            return interaction.reply({ content: 'Only the Founder can start the draw.', ephemeral: true });
          }

          if (giveawayParticipants.length === 0) {
            return interaction.reply({ content: 'No one has joined the giveaway yet!', ephemeral: true });
          }

          const drawChannel = interaction.channel;
          if (!drawChannel || !(drawChannel instanceof TextChannel)) return;

          await interaction.reply({ content: 'How many minutes for the cooldown? (Send a message with the number)', ephemeral: true });
          
          const filter = (m: any) => m.author.id === interaction.user.id;
          const collector = drawChannel.createMessageCollector({ filter, time: 15000, max: 1 });

          collector.on('collect', async (m: any) => {
            const minutes = parseInt(m.content);
            if (isNaN(minutes)) {
              await interaction.followUp({ content: 'Invalid number. Draw cancelled.', ephemeral: true });
              return;
            }

            await interaction.followUp({ content: `Draw will occur in ${minutes} minutes.`, ephemeral: true });
            
            // Send cooldown message to the ORIGINAL giveaway channel if possible
            if (giveawayMessageId) {
              const giveawayChan = interaction.guild?.channels.cache.find(c => c.isTextBased() && (c as TextChannel).messages.cache.has(giveawayMessageId!)) as TextChannel;
              if (giveawayChan) {
                await giveawayChan.send({ 
                  content: `⏳ **Giveaway ending in ${minutes} minute(s)!** Cooldown active.` 
                });
              }
            }

            setTimeout(async () => {
              const winnerId = giveawayParticipants[Math.floor(Math.random() * giveawayParticipants.length)];
              
              // Announce result in giveaway channel
              if (giveawayMessageId) {
                const giveawayChan = interaction.guild?.channels.cache.find(c => c.isTextBased() && (c as TextChannel).messages.cache.has(giveawayMessageId!)) as TextChannel;
                if (giveawayChan) {
                  await giveawayChan.send({
                    embeds: [{
                      title: '🎉 GIVEAWAY RESULT!',
                      description: `The lucky winner is <@${winnerId}>! Congratulations!`,
                      color: 0xFF0000
                    }]
                  });
                }
              }

              // Set reset timeout for 2 days
              if (giveawayResetTimeout) clearTimeout(giveawayResetTimeout);
              giveawayResetTimeout = setTimeout(() => {
                giveawayParticipants = [];
                giveawayActive = false;
              }, 2 * 24 * 60 * 60 * 1000);

            }, minutes * 60 * 1000);
          });
        }

        if (interaction.customId === 'claim_ticket') {
          const member = interaction.member as any;
          if (!member.roles.cache.has(SUPPORT_ROLE_ID) && !member.roles.cache.has(OWNER_ROLE_ID)) {
            return interaction.reply({ content: 'Only support staff can claim tickets.', ephemeral: true });
          }
          await channel.send({ embeds: [{ description: `📜 Ticket claimed by <@${interaction.user.id}>`, color: 0xFF0000 }] });
          await interaction.reply({ content: 'Ticket claimed!', ephemeral: true });
        }

        if (interaction.customId === 'close_ticket') {
          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId('confirm_close_ticket').setLabel('Yes, Close').setStyle(ButtonStyle.Danger)
          );
          await interaction.reply({ embeds: [{ description: '⚠️ Are you sure you want to close this ticket?', color: 0xFF0000 }], components: [row] });
        }

        if (interaction.customId === 'confirm_close_ticket') {
          await channel.send({ embeds: [{ description: `🔒 Ticket closed by <@${interaction.user.id}>`, color: 0xFF0000 }] });
          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId('delete_ticket').setLabel('Delete').setStyle(ButtonStyle.Danger)
          );
          await interaction.reply({ embeds: [{ description: 'The ticket is now closed. Use the button below to delete it.', color: 0xFF0000 }], components: [row] });
        }

        if (interaction.customId === 'delete_ticket') {
          const member = interaction.member as any;
          if (!member.roles.cache.has(OWNER_ROLE_ID)) {
            return interaction.reply({ content: 'Only Owners can delete tickets.', ephemeral: true });
          }
          await interaction.reply({ embeds: [{ description: '🗑️ Ticket will be deleted in a few seconds...', color: 0xFF0000 }] });
          setTimeout(() => channel.delete().catch(console.error), 5000);
        }
      }
    });

    client.on('voiceStateUpdate', async (oldState, newState) => {
      const TRIGGER_VC_ID = "1382055327670734938";
      const CATEGORY_ID = "1349800786154098728";
      const SUPPORT_ROLE_ID = "1348431461589454942";
      const NOTIF_CHANNEL_ID = "1464401027699703980";

      if (newState.channelId === TRIGGER_VC_ID && oldState.channelId !== TRIGGER_VC_ID) {
        const member = newState.member;
        if (!member) return;
        try {
          const supportVC = await newState.guild.channels.create({
            name: "📞Sᴜᴘᴘᴏʀᴛ",
            type: ChannelType.GuildVoice,
            parent: CATEGORY_ID,
            permissionOverwrites: [
              { id: newState.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
              { id: member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
              { id: SUPPORT_ROLE_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
            ],
          });
          await member.voice.setChannel(supportVC);

          // Notification for Join-to-Create Voice Room
          try {
            const notifChannel = await newState.guild.channels.fetch(NOTIF_CHANNEL_ID).catch(() => null) as TextChannel | null;
            if (notifChannel && notifChannel.isTextBased()) {
              await notifChannel.send({
                embeds: [{
                  title: '🔊 Voice Support Requested',
                  description: `👤 **User:** <@${member.id}> (${member.user.username}) is waiting in a support voice room!\n📍 **Channel:** <#${supportVC.id}>`,
                  color: 0xFF0000,
                  timestamp: new Date().toISOString()
                }]
              });
            }
          } catch (err) { console.error('Error sending voice notif:', err); }
        } catch (error) { console.error(error); }
      }

      if (oldState.channel && oldState.channel.name === "📞Sᴜᴘᴘᴏʀᴛ" && oldState.channel.parentId === CATEGORY_ID) {
        if (oldState.channel.members.size === 0) {
          try { await oldState.channel.delete(); } catch (error) { console.error(error); }
        }
      }
    });

    client.on('messageCreate', async message => {
      if (message.author.bot) return;
      const USER_INFO_CHANNEL_ID = "1463137773144903785";
      
      if (message.channelId === USER_INFO_CHANNEL_ID) {
        const content = message.content.toLowerCase().trim();
        
        // Delete the user's message regardless to keep channel clean
        setTimeout(() => message.delete().catch(() => {}), 100);

        if (content === '!info') {
          const member = message.member;
          if (!member) return;

          const roles = member.roles.cache
            .filter(role => role.name !== '@everyone')
            .map(role => `<@&${role.id}>`)
            .join(', ') || 'No roles';

          await message.channel.send({
            content: `<@${message.author.id}>`,
            embeds: [{
              title: `👤 ${message.author.username}`,
              description: `**Πληροφορίες Χρήστη**\nID: \`${message.author.id}\`\nΌνομα: <@${message.author.id}>\nΕγγραφή στο Discord: <t:${Math.floor(message.author.createdAt.getTime() / 1000)}:F> (<t:${Math.floor(message.author.createdAt.getTime() / 1000)}:R>)\n\n**Πληροφορίες Μέλους**\nΕίσοδος στον Server: ${member.joinedAt ? `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:F> (<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>)` : 'Άγνωστο'}\n\n**Roles**\n${roles}`,
              thumbnail: { url: message.author.displayAvatarURL({ size: 512 }) },
              color: 0xFF0000,
              footer: { text: 'Cheat Shop | User Info', icon_url: client.user?.displayAvatarURL() }
            }]
          });
        } else {
          // Send a temporary public reminder instead of DM
          const reply = await message.channel.send({ 
            content: `⚠️ <@${message.author.id}>, You can only type "!info"` 
          });
          setTimeout(() => reply.delete().catch(() => {}), 4000);
        }
      }
    });

    client.on('guildMemberAdd', async member => {
      const AUTO_ROLE_ID = "1348435737279725578";
      const WELCOME_CHANNEL_ID = "1366366771686146079";
      try {
        await member.roles.add(AUTO_ROLE_ID);
        const channel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID) as TextChannel;
        if (channel) {
          await channel.send({
            embeds: [{
              title: `👋 Καλώς ήρθες ${member.user.username}`,
              description: `Καλώς ήρθες στον server Cheat Shop!`,
              thumbnail: { url: member.user.displayAvatarURL({ size: 256 }) },
              color: 0xFF0000,
            }]
          });
        }
      } catch (error) { console.error(error); }
    });

  } catch (error) {
    console.error("Discord bot error:", error);
  }
}
