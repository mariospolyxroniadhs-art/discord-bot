import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { setupDiscordBot } from "./bot";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Initialize Discord Bot
  try {
    await setupDiscordBot();
  } catch (error) {
    console.error("Failed to setup Discord bot:", error);
  }

  app.get(api.status.get.path, (req, res) => {
    res.json({ status: "online", uptime: process.uptime() });
  });

  return httpServer;
}
