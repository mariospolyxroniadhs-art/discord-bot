# BotPanel - Discord Bot Dashboard

## Overview

BotPanel is a full-stack web application that serves as a landing page and dashboard for a Discord bot. The project combines a React-based frontend with an Express backend, featuring a Discord.js bot integration. The application displays bot status, feature highlights, and provides a modern gaming-aesthetic interface with Discord-inspired dark theming.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Animations**: Framer Motion for complex animations
- **Build Tool**: Vite with hot module replacement

The frontend follows a component-based architecture with:
- Pages in `client/src/pages/`
- Reusable UI components in `client/src/components/ui/` (shadcn/ui)
- Custom components in `client/src/components/`
- Hooks in `client/src/hooks/`
- Path aliases configured: `@/` → `client/src/`, `@shared/` → `shared/`

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with tsx for TypeScript execution
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Discord Integration**: discord.js v14 for bot functionality

The server structure:
- `server/index.ts` - Express app entry point with middleware setup
- `server/routes.ts` - API route registration
- `server/db.ts` - Database connection using pg Pool
- `server/storage.ts` - Data access layer with repository pattern
- `server/bot.ts` - Discord bot setup with slash commands
- `server/vite.ts` - Vite dev server integration
- `server/static.ts` - Static file serving for production

### Shared Code
- `shared/schema.ts` - Drizzle database schema definitions with Zod validation
- `shared/routes.ts` - API route definitions with type-safe contracts

### Build System
- Development: `tsx server/index.ts` with Vite middleware
- Production: Custom build script using esbuild for server, Vite for client
- Output: `dist/` directory with bundled server and `dist/public/` for client assets

### Database Schema
Currently defines a `messages` table for logging Discord messages:
- `id` (serial, primary key)
- `content` (text)
- `sentBy` (text)
- `channelId` (text)
- `createdAt` (text)

## External Dependencies

### Database
- **PostgreSQL**: Primary database accessed via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database operations with `drizzle-kit` for migrations

### Discord Integration
- **discord.js**: Bot framework requiring `DISCORD_TOKEN` and optionally `DISCORD_CLIENT_ID`
- Bot features: Slash command registration, message sending capabilities

### UI Component Library
- **shadcn/ui**: Pre-built accessible components using Radix UI primitives
- **Radix UI**: Headless UI components (dialog, dropdown, tabs, etc.)
- **class-variance-authority**: Component variant management

### Required Environment Variables
- `DATABASE_URL` - PostgreSQL connection string (required)
- `DISCORD_TOKEN` - Discord bot token (optional, bot won't start without it)
- `DISCORD_CLIENT_ID` - Discord application ID (optional, needed for slash commands)

### Key NPM Packages
- `@tanstack/react-query` - Async state management
- `framer-motion` - Animation library
- `wouter` - Client-side routing
- `zod` - Schema validation
- `connect-pg-simple` - Session storage (available but not actively used)